setTimeout(function () {
    $("div#animate").removeClass("hide").addClass("show");
}, 2000);

/* add the outro animation codes and setTimeOut codes */

document.getElementById('kmore').onclick = function () {
	var inth = document.getElementById('intro');
	inth.style.display = "none";
};